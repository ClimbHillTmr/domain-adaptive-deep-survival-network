import os
import yaml
import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import shap
from pathlib import Path
from sklearn.manifold import TSNE
from lifelines import KaplanMeierFitter

from src.models.cdan_gsn import DomainStratifiedGatedNet
from src.data.dataset import prepare_dataloaders

import matplotlib
# Use a font that supports Chinese to avoid warnings
matplotlib.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'SimHei', 'DejaVu Sans', 'Arial', 'sans-serif']
matplotlib.rcParams['axes.unicode_minus'] = False

# Set academic plotting style
plt.style.use('default')
sns.set_theme(style="whitegrid", palette="colorblind")
plt.rcParams.update({
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
    'axes.labelsize': 12,
    'axes.titlesize': 14,
    'xtick.labelsize': 10,
    'ytick.labelsize': 10,
    'legend.fontsize': 10,
})

def load_config(config_path="conf/config.yaml"):
    with open(config_path, "r") as f:
        return yaml.safe_load(f)

def get_indices(feature_names):
    treat_features = [
        "超滤比", "超滤率_绝对", "超滤率_体重归一化", "超滤量MAX",
        "透析液电导率", "透析液钙浓度", "抗凝剂类型_code",
        "瘘管位置_code", "瘘管类型_code", "透析方式_code"
    ]
    treat_indices = []
    physio_indices = []
    for i, name in enumerate(feature_names):
        if any(t in name for t in treat_features):
            treat_indices.append(i)
        else:
            physio_indices.append(i)
    return treat_indices, physio_indices

def plot_tsne_alignment(model, source_loader, target_loader, device, out_dir):
    """
    Fig 2: t-SNE Latent Space Alignment
    Visualizes the feature representations of Source and Target domains to verify DA effectiveness.
    """
    print("Generating Fig 2: t-SNE Domain Alignment Plot...")
    model.eval()
    
    embeddings = []
    labels = []
    
    with torch.no_grad():
        # Get Source embeddings
        for i, (x_s, _, _, _) in enumerate(source_loader):
            if i > 5: break  # Limit sample size for clarity
            cls_emb, _, _, _ = model(x_s.to(device))
            embeddings.append(cls_emb.cpu().numpy())
            labels.extend(["Shenyi (Source)"] * x_s.size(0))
            
        # Get Target embeddings
        for i, (x_t, _, _, _) in enumerate(target_loader):
            if i > 5: break
            cls_emb, _, _, _ = model(x_t.to(device))
            embeddings.append(cls_emb.cpu().numpy())
            labels.extend(["Fuding (Target)"] * x_t.size(0))
            
    embeddings = np.concatenate(embeddings, axis=0)
    labels = np.array(labels)
    
    # Run t-SNE
    tsne = TSNE(n_components=2, random_state=42, perplexity=30)
    tsne_results = tsne.fit_transform(embeddings)
    
    # Plot
    plt.figure(figsize=(8, 6))
    sns.scatterplot(
        x=tsne_results[:, 0], y=tsne_results[:, 1],
        hue=labels,
        palette={"Shenyi (Source)": "#0072B2", "Fuding (Target)": "#D55E00"},
        alpha=0.6, s=30, edgecolor=None
    )
    plt.title("Fig 2: Latent Space Alignment (t-SNE)")
    plt.xlabel("t-SNE Dimension 1")
    plt.ylabel("t-SNE Dimension 2")
    plt.legend(title="Domain", frameon=True)
    
    plt.savefig(out_dir / "fig2_tsne_alignment.pdf", bbox_inches='tight', dpi=300)
    plt.close()
    print("-> Saved fig2_tsne_alignment.pdf")

def plot_shap_analysis(model, x_bg, x_test, feature_names, out_dir):
    """
    Fig 3: SHAP Global Summary and Dependence Plots
    """
    print("Generating Fig 3: SHAP Interpretability Plots...")
    
    # Wrapper function for SHAP
    def model_predict(x):
        x_tensor = torch.tensor(x, dtype=torch.float32, device=x_bg.device)
        with torch.no_grad():
            _, hazard, _, _ = model(x_tensor)
        return hazard.cpu().numpy()
        
    x_bg_np = x_bg.cpu().numpy()
    x_test_np = x_test.cpu().numpy()
    
    # Use KernelExplainer for complex custom architectures
    explainer = shap.KernelExplainer(model_predict, shap.kmeans(x_bg_np, 10))
    shap_values = explainer.shap_values(x_test_np[:100]) # limit to 100 for speed
    x_test_plot = x_test_np[:100]
    
    if isinstance(shap_values, list):
        shap_values = shap_values[0]
        
    shap_values_np = shap_values.reshape(x_test_plot.shape[0], -1) if len(shap_values.shape) > 2 else shap_values
    
    # Fig 3a: Summary Plot
    plt.figure(figsize=(10, 8))
    shap.summary_plot(shap_values_np, x_test_plot, feature_names=feature_names, show=False)
    plt.savefig(out_dir / "fig3a_shap_summary.pdf", bbox_inches='tight', dpi=300)
    plt.close()
    print("-> Saved fig3a_shap_summary.pdf")
    
    # Fig 3b: Dependence Plot for top feature
    mean_abs_shap = np.abs(shap_values_np).mean(axis=0)
    top_idx = np.argsort(mean_abs_shap)[::-1][0]
    
    plt.figure(figsize=(8, 6))
    shap.dependence_plot(
        top_idx, shap_values_np, x_test_plot, 
        feature_names=feature_names, show=False, interaction_index=None
    )
    plt.title(f"SHAP Dependence: {feature_names[top_idx]}")
    plt.savefig(out_dir / "fig3b_shap_dependence_top1.pdf", bbox_inches='tight', dpi=300)
    plt.close()
    print("-> Saved fig3b_shap_dependence_top1.pdf")

def plot_km_risk_stratification(model, x_test, e_test, t_test, device, out_dir, batch_size=256):
    """
    Fig 4: Kaplan-Meier Risk Stratification Curves
    Splits patients into Low, Medium, and High risk based on predicted hazard
    and plots their actual survival curves.
    """
    print("Generating Fig 4: Kaplan-Meier Risk Stratification Curves...")
    model.eval()
    
    hazards = []
    with torch.no_grad():
        for start in range(0, len(x_test), batch_size):
            end = start + batch_size
            x_batch = torch.tensor(x_test[start:end], dtype=torch.float32, device=device)
            _, hazard, _, _ = model(x_batch)
            hazards.append(hazard.squeeze().cpu().numpy())
    
    hazards = np.concatenate(hazards, axis=0)
        
    # Define risk groups based on quantiles (33.3% and 66.6%)
    q33 = np.percentile(hazards, 33.3)
    q67 = np.percentile(hazards, 66.7)
    
    risk_groups = np.zeros_like(hazards, dtype=int)
    risk_groups[hazards > q33] = 1
    risk_groups[hazards > q67] = 2
    
    plt.figure(figsize=(8, 6))
    kmf = KaplanMeierFitter()
    
    colors = ["#009E73", "#E69F00", "#D55E00"]
    labels = ["Low Risk", "Medium Risk", "High Risk"]
    
    for i in range(3):
        mask = (risk_groups == i)
        if mask.sum() > 0:
            kmf.fit(t_test[mask], event_observed=e_test[mask], label=labels[i])
            kmf.plot_survival_function(color=colors[i], ci_show=True, linewidth=2)
            
    plt.title("Fig 4: Kaplan-Meier Risk Stratification (Target Domain)")
    plt.xlabel("Time (minutes)")
    plt.ylabel("Survival Probability (IDH-free)")
    plt.ylim(0.0, 1.05)
    plt.xlim(0, max(t_test) + 10)
    
    # Add a horizontal line at 0.5 if it drops that low, or just grid
    plt.grid(True, alpha=0.3)
    plt.legend(loc='lower left')
    
    plt.savefig(out_dir / "fig4_km_risk_stratification.pdf", bbox_inches='tight', dpi=300)
    plt.close()
    print("-> Saved fig4_km_risk_stratification.pdf")

def main():
    print("="*50)
    print("Generating Academic Clinical Figures")
    print("="*50)
    
    config = load_config()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out_dir = Path(config["paths"]["figure_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    
    # 1. Load Data
    data_dict = prepare_dataloaders(
        source_path=os.path.join(config["paths"]["data_dir"], config["data"]["source_file"]),
        target_path=os.path.join(config["paths"]["data_dir"], config["data"]["target_file"]),
        batch_size=config["training"]["batch_size"],
        seed=config["training"]["seed"]
    )
    
    treat_indices, physio_indices = get_indices(data_dict["feature_names"])
    
    # 2. Load Model
    model = DomainStratifiedGatedNet(
        input_dim=data_dict["input_dim"],
        d_model=config["model"]["d_model"],
        nhead=config["model"]["num_heads"],
        num_layers=config["model"]["num_layers"],
        dropout=config["model"]["dropout"],
        domain_hidden=config["model"]["domain_hidden"],
        treat_indices=treat_indices,
        physio_indices=physio_indices,
        tokenizer_type="kan",
        kan_basis_dim=config["model"]["kan_bases"]
    ).to(device)
    
    # Note: In a real pipeline, load the best model weights here:
    # model.load_state_dict(torch.load("experiments/results/best_model.pth"))
    
    # 3. Generate Figures
    # Fig 2: t-SNE
    plot_tsne_alignment(model, data_dict["source_loader"], data_dict["target_loader"], device, out_dir)
    
    # Fig 3: SHAP
    x_bg_tensor = []
    for x_s, _, _, _ in data_dict["source_loader"]:
        x_bg_tensor.append(x_s)
        if len(x_bg_tensor) * config["training"]["batch_size"] > 200: break
    x_bg = torch.cat(x_bg_tensor, dim=0)[:200].to(device)
    x_test_tensor = torch.tensor(data_dict["x_test"][:500], dtype=torch.float32).to(device)
    
    plot_shap_analysis(model, x_bg, x_test_tensor, data_dict["feature_names"], out_dir)
    
    # Fig 4: KM Curves
    plot_km_risk_stratification(
        model, data_dict["x_test"], data_dict["e_test"], data_dict["t_test"], 
        device, out_dir
    )
    
    print("\nAll figures generated successfully in the 'figures/' directory.")

if __name__ == "__main__":
    main()
